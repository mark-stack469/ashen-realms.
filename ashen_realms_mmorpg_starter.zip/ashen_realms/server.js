const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("./db");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
const PORT = process.env.PORT || 3000;
const SECRET = process.env.JWT_SECRET || "CHANGE_THIS_SECRET_BEFORE_DEPLOYMENT";
const WORLD = { width: 1800, height: 1200 };
const online = new Map();

app.use(express.json({ limit: "20kb" }));
app.use(express.static("public"));

function tokenFor(user) {
  return jwt.sign({ id: user.id, username: user.username }, SECRET, { expiresIn: "14d" });
}
function auth(req, res, next) {
  try {
    const raw = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
    req.user = jwt.verify(raw, SECRET);
    next();
  } catch { res.status(401).json({ error: "Требуется вход в аккаунт" }); }
}
function getCharacter(userId) {
  return db.prepare("SELECT * FROM characters WHERE user_id=?").get(userId);
}
function publicCharacter(c) {
  return { id: c.user_id, name: c.name, level: c.level, hp: c.hp, x: c.x, y: c.y };
}

app.post("/api/register", async (req, res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  if (!/^[a-zA-Z0-9_]{3,18}$/.test(username))
    return res.status(400).json({ error: "Логин: 3–18 символов, латиница, цифры или _" });
  if (password.length < 8) return res.status(400).json({ error: "Пароль должен содержать минимум 8 символов" });
  try {
    const hash = await bcrypt.hash(password, 12);
    const info = db.prepare("INSERT INTO users(username,password_hash) VALUES(?,?)").run(username, hash);
    const user = { id: Number(info.lastInsertRowid), username };
    return res.json({ token: tokenFor(user), user, character: null });
  } catch { return res.status(409).json({ error: "Такой логин уже занят" }); }
});

app.post("/api/login", async (req, res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE username=?").get(username);
  if (!user || !(await bcrypt.compare(password, user.password_hash)))
    return res.status(401).json({ error: "Неверный логин или пароль" });
  const safe = { id: user.id, username: user.username };
  res.json({ token: tokenFor(safe), user: safe, character: getCharacter(user.id) || null });
});

app.get("/api/me", auth, (req, res) => {
  res.json({ user: req.user, character: getCharacter(req.user.id) || null });
});

app.post("/api/character", auth, (req, res) => {
  const name = String(req.body.name || "").trim();
  if (!/^[А-Яа-яЁёA-Za-z0-9_ ]{3,16}$/.test(name))
    return res.status(400).json({ error: "Имя персонажа: 3–16 допустимых символов" });
  if (getCharacter(req.user.id)) return res.status(409).json({ error: "Персонаж уже создан" });
  db.prepare("INSERT INTO characters(user_id,name) VALUES(?,?)").run(req.user.id, name);
  res.json({ character: getCharacter(req.user.id) });
});

app.get("/api/health", (_, res) => res.json({ ok: true, online: online.size }));

io.use((socket, next) => {
  try {
    const payload = jwt.verify(socket.handshake.auth?.token, SECRET);
    const character = getCharacter(payload.id);
    if (!character) return next(new Error("Сначала создай персонажа"));
    socket.user = payload;
    socket.character = character;
    next();
  } catch { next(new Error("Недействительный токен")); }
});

io.on("connection", socket => {
  const c = getCharacter(socket.user.id);
  const player = { ...publicCharacter(c), socketId: socket.id };
  online.set(socket.user.id, player);
  socket.emit("world:init", {
    selfId: socket.user.id,
    world: WORLD,
    players: [...online.values()].filter(p => p.id !== socket.user.id).map(({socketId,...p}) => p),
    mobs: [{id:"ghoul-1",name:"Голодный упырь",x:850,y:500,hp:40,maxHp:40}]
  });
  socket.broadcast.emit("player:join", (({socketId,...p}) => p)(player));

  socket.on("player:move", data => {
    const current = online.get(socket.user.id);
    if (!current || !data) return;
    const x = Math.max(30, Math.min(WORLD.width - 30, Number(data.x) || current.x));
    const y = Math.max(30, Math.min(WORLD.height - 30, Number(data.y) || current.y));
    current.x = x; current.y = y;
    socket.broadcast.emit("player:move", { id: current.id, x, y });
  });

  socket.on("chat:send", raw => {
    const message = String(raw || "").trim().slice(0,160);
    if (!message) return;
    io.emit("chat:message", { name: c.name, level: c.level, message, at: Date.now() });
  });

  socket.on("disconnect", () => {
    online.delete(socket.user.id);
    socket.broadcast.emit("player:leave", { id: socket.user.id });
  });
});

setInterval(() => {
  for (const player of online.values()) {
    const c = getCharacter(player.id);
    if (c && (Math.abs(c.x-player.x) > 0.1 || Math.abs(c.y-player.y) > 0.1))
      db.prepare("UPDATE characters SET x=?,y=? WHERE user_id=?").run(player.x,player.y,player.id);
  }
}, 5000);

server.listen(PORT, () => console.log(`ASHEN REALMS running on http://localhost:${PORT}`));