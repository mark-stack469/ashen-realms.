const Database = require("better-sqlite3");
const db = new Database(process.env.DB_FILE || "ashen-realms.sqlite");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS characters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  level INTEGER NOT NULL DEFAULT 1,
  xp INTEGER NOT NULL DEFAULT 0,
  hp INTEGER NOT NULL DEFAULT 100,
  gold INTEGER NOT NULL DEFAULT 25,
  x REAL NOT NULL DEFAULT 500,
  y REAL NOT NULL DEFAULT 400,
  inventory TEXT NOT NULL DEFAULT '["Ржавый меч","Малое зелье"]'
);
`);
module.exports = db;